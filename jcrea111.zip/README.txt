JCreator Release Version 1.11 (32 bit) for Win 95/98/NT/2000. 
Copyright (C) 2000 Xinox Software
All Rights Reserved.

Contents:

  1. The purpose of the program.
  2. The installation.
  3. License and distribution status of the program.
  4. How to contact the author.
 

#The purpose of the program.

JCreator is a powerful editor for Java technologies. Especially designed for the student
and the semi-professional Java-Engineers. JCreator is designed to meet windows interface 
guidelines, so the users can expect a familiar and intuitive user interface. 

#The installation.

Unzip the installation file JCreatorSetup.exe in a temporary directory and run it. 
The installation wizard will do the rest. It's essential to restart your system after
the installation. The JCreator shortcut and the uninstallation program will appear 
in the Start-programs folder.

#License and distribution status of the program.

JCreator is Freeware, but before you use it read the enclosed EULA file for more 
info about this topic.

#How to contact the author.

For the latest updates and news:
http://www.jcreator.com

Support  : support@jcreator.com
Comments : wendeldw@jcreator.com












